from fastapi import FastAPI, Response, status
from pydantic import BaseModel
from typing import Optional

app = FastAPI()

class Product(BaseModel):
    id: int
    name: str
    price: int
    category: str
    in_stock: bool = True

class NewProduct(BaseModel):
    name: str
    price: int
    category: str
    in_stock: bool = True

products = [
    {"id":1,"name":"Wireless Mouse","price":599,"category":"Electronics","in_stock":True},
    {"id":2,"name":"Notebook","price":99,"category":"Stationery","in_stock":True},
    {"id":3,"name":"USB Hub","price":799,"category":"Electronics","in_stock":False},
    {"id":4,"name":"Pen Set","price":199,"category":"Stationery","in_stock":True}
]

def find_product(product_id:int):
    for p in products:
        if p["id"] == product_id:
            return p
    return None


@app.get("/products")
def get_products():
    return {"products":products,"total":len(products)}


@app.get("/products/{product_id}")
def get_product(product_id:int, response:Response):
    product=find_product(product_id)
    if not product:
        response.status_code=status.HTTP_404_NOT_FOUND
        return {"error":"Product not found"}
    return product


@app.post("/products")
def add_product(new_product:NewProduct, response:Response):
    for p in products:
        if p["name"]==new_product.name:
            response.status_code=status.HTTP_400_BAD_REQUEST
            return {"error":"Product already exists"}

    next_id=max(p["id"] for p in products)+1

    product={
        "id":next_id,
        "name":new_product.name,
        "price":new_product.price,
        "category":new_product.category,
        "in_stock":new_product.in_stock
    }

    products.append(product)

    response.status_code=status.HTTP_201_CREATED

    return {"message":"Product added","product":product}


@app.put("/products/{product_id}")
def update_product(product_id:int, price:Optional[int]=None, in_stock:Optional[bool]=None, response:Response=None):

    product=find_product(product_id)

    if not product:
        response.status_code=status.HTTP_404_NOT_FOUND
        return {"error":"Product not found"}

    if price is not None:
        product["price"]=price

    if in_stock is not None:
        product["in_stock"]=in_stock

    return {"message":"Product updated","product":product}


@app.delete("/products/{product_id}")
def delete_product(product_id:int, response:Response):

    product=find_product(product_id)

    if not product:
        response.status_code=status.HTTP_404_NOT_FOUND
        return {"error":"Product not found"}

    products.remove(product)

    return {"message":f"Product '{product['name']}' deleted"}